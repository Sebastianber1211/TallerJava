
public class Notas {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 // Crear dos objetos de la clase Notas
        nota notas1 = new nota("1041147271", "Java", 4.5, 3.0);
        nota notas2 = new nota("32160662", "Css", 3.0, 2.5);
		
     // Imprimir los objetos
        System.out.println("Notas del estudiante 1:");
        System.out.println(notas1);

        System.out.println("\nNotas del estudiante 2:");
        System.out.println(notas2);
		
	
	
		
		
		
	

		
	}

}
