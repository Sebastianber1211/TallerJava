
public class Billeteraelectronica {

	
	double capital; 
	
	public Billeteraelectronica() {
		this.capital = 0.0;
	}

	public void depositar(double cantidad) {
		this.capital += cantidad;
		System.out.println("Depósito exitoso. Nuevo capital: " + this.capital);
	}
	
	public void retirar(double cantidad) {
		if (cantidad > this.capital) {
			System.out.println("No puedes retirar más dinero del que tienes en la billetera");
		} 
		else {
		this.capital -= cantidad;
		System.out.println("Retiro exitoso. Nuevo capital: " + this.capital);
		}
	}
	
	public void mostrarSaldo() {
		System.out.println("Tu saldo actual es: " + this.capital);
	}
	
}
