
public class Notas {

	//Definir variables 
	int nota60;
	int nota40;
	String documento; 
	String asignatura;
	
	//Definir el estructur  de la clase 
	Notas(String documento, String asignatura, int nota60, int nota40){
		this.documento = documento;
		this.asignatura = asignatura; 
		this.nota60 = nota60;
		this.nota40 = nota40;
	}
	
	//Metodos set
	public void setNota60(int  nota60) { 
		this.nota60 = nota60;
		}

	public void setNota40(int nota40) { 
		this.nota40 = nota40;
		}
	
	public void setDocumento(String documento) { 
		this.documento = documento;
		}
	
	public void setAsignatura(String asignatura) { 
		this.asignatura = asignatura;
		}
	
		//Defeniir get
	public int getNota60() { 
		return this.nota60;
	}	
	
	public int getNota40() { 
		return this.nota40;
	}	
		
	public  String getDcocumento() { 
		return this.documento;
	}	
		
	
	public  String getAsignatura() { 
	return this.asignatura;
	}	
	
	//Asignar otros metodos 
	public void CalcularNotaFinal() {
		System.out.println("La nota final fue calculada");
	}
	
	//Verificar	
	@Override
	public String toString() {
		return "nota60: "+ this.nota60+
				"\nnota40: "+ this.nota40+"\ndocumento: "+ this.documento+
				"\nasignatura: "+ this.asignatura;

	
	}
	
	
	

	
}
