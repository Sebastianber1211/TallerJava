
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Circulo circulo1 = new Circulo(5.0);
	Cuadrado cuadrado1 = new Cuadrado(4.0);
	Rectangulo rectangulo1 = new Rectangulo(3.0,6.0);
	
    System.out.println("Área del círculo: " + circulo1.calcularArea());
    System.out.println("Perímetro del círculo: " + circulo1.calcularPerimetro());

    System.out.println("Área del cuadrado: " + cuadrado1.calcularArea());
    System.out.println("Perímetro del cuadrado: " + cuadrado1.calcularPerimetro());

    System.out.println("Área del rectángulo: " + rectangulo1.calcularArea());
    System.out.println("Perímetro del rectángulo: " + rectangulo1.calcularPerimetro());
	

	
	
	}

}
