
public class Casa extends Inmueble {
    public Casa(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
    }

    public int calcularValorVentaPesos() {
        return (int) (area * valormetrocuadrado);
    }


    public double calcularValorVentaDolares() {
        return area * valormetrocuadrado;
    }


    public int calcularAvaluoCatastralPesos() {
        return (int) (calcularValorVentaPesos() * 0.6);
    }

 
    public double calcularAvaluoCatastralDolares() {
        return calcularValorVentaDolares() * 0.6;
    }
}