
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		        Apartamento apartamento = new Apartamento(1, "Bogotá", "Cra 123", 80.0, 3000000.0, 1500000.0);

		        // Calcular valor de venta en pesos
		        int valorVentaPesos = apartamento.calcularValorVentaPesos();
		        System.out.println("Valor de venta en pesos: " + valorVentaPesos);

		        // Calcular valor de venta en dólares
		        double valorVentaDolares = apartamento.calcularValorVentaDolares();
		        System.out.println("Valor de venta en dólares: " + valorVentaDolares);

		        // Calcular avalúo catastral en pesos
		        int avaluoPesos = apartamento.calcularAvaluoCatastralPesos();
		        System.out.println("Avalúo catastral en pesos: " + avaluoPesos);

		        // Calcular avalúo catastral en dólares
		        double avaluoDolares = apartamento.calcularAvaluoCatastralDolares();
		        System.out.println("Avalúo catastral en dólares: " + avaluoDolares);
		    }
		}

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
