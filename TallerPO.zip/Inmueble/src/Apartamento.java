
public class Apartamento extends Inmueble {
	
    
		public Apartamento(int codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
    }

 
    public int calcularValorVentaPesos() {
        return (int) (area * valormetrocuadrado);
    }


    public double calcularValorVentaDolares() {
        return area * valormetrocuadrado;
    }

    @Override
    public int calcularAvaluoCatastralPesos() {
        return (int) (calcularValorVentaPesos() * 0.7);
    }


    public double calcularAvaluoCatastralDolares() {
        return calcularValorVentaDolares() * 0.7;
    }
}