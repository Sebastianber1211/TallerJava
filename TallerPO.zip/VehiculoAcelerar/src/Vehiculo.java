
public class Vehiculo {

	String marca;
	String modelo;
	int velocidad;
	
	public Vehiculo(String marca, String modelo, int velocidad) {
		this.marca = marca;
		this.modelo = modelo;
		this.velocidad = velocidad;
	} 
	
	public void acelerar(int cantidad) {
		this.velocidad += cantidad; 
		System.out.println("El vehiculo acelero. velocidad actual: " +this.velocidad + " km/h");
	}
	
    public void desacelerar(int cantidad) {
        if (this.velocidad - cantidad < 0) {
            this.velocidad = 0;
        } else {
            this.velocidad -= cantidad;
        }
        System.out.println("El vehículo desaceleró. Velocidad actual: " + this.velocidad + " km/h");
    }

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}
	
}
