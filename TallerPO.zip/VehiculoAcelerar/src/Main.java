
public class Main {

	public static void main(String[] args) {
		// crear vehiculo
		Vehiculo vehiculo1 = new Vehiculo("Toyota", "Corolla", 30);
		
		
		
		//Mostrar informacion inicial 
		System.out.println("Vehiculo" + vehiculo1.getMarca() );
        System.out.println("Velocidad inicial: " + vehiculo1.getVelocidad() + " km/h");

        // Acelerar el vehículo
        vehiculo1.acelerar(50);

        // Desacelerar el vehículo
        vehiculo1.desacelerar(20);

        // Establecer nueva velocidad
        vehiculo1.setVelocidad(40);
        System.out.println("Nueva velocidad: " + vehiculo1.getVelocidad() + " km/h");
		
		
		

				
	}

}
