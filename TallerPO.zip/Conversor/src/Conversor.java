
public class Conversor {
	double valorPesos;

    // Constructor
    public Conversor(double cantidadPesos) {
        this.valorPesos = cantidadPesos;
    }

    // Métodos getter y setter
    public double getCantidadPesos() {
        return valorPesos;
    }

    public void setCantidadPesos(double cantidadPesos) {
        this.valorPesos = cantidadPesos;
    }

    // Método para convertir a dólares
    public double convertirDolares() {
    	
        // Tasa de cambio Dolares
        double CambioDolares = 0.00027;
        return valorPesos* CambioDolares;
    }

    // Método para convertir a euros
    public double convertirEuros() {
    	
        // Tasa de cambio Euros
        double CambioEuros = 0.00023;
        return valorPesos * CambioEuros;
    }

}
